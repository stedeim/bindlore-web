# Meditations — Book IV

**Cite as:** Meditations, Book IV, §II or §III (`references/book-04.md`)

Source: Marcus Aurelius, *Meditations*. Public-domain English translation by Meric Casaubon (1634). Sample chapter reference illustrating Bindlore's output format. Not OCR of a copyrighted edition.

## §II

Let nothing be done rashly, and at random, but all things according to the most exact and perfect rules of art.

## §III

They seek for themselves private retiring places, as country villages, the sea-shore, mountains; yea thou thyself art wont to long much after such places. But all this thou must know proceeds from simplicity in the highest degree. At what time soever thou wilt, it is in thy power to retire into thyself, and to be at rest, and free from all businesses. A man cannot any whither retire better than to his own soul; he especially who is beforehand provided of such things within, which whensoever he doth withdraw himself to look in, may presently afford unto him perfect ease and tranquillity. By tranquillity I understand a decent orderly disposition and carriage, free from all confusion and tumultuousness. Afford then thyself this retiring continually, and thereby refresh and renew thyself.
